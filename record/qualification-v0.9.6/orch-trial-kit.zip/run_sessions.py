#!/usr/bin/env python3
"""Validate the two controls, then run six implementer sessions (stand-ins, billed like real ones).

  python3 run_sessions.py CONTROLS_DIR OUT_DIR

Writes OUT_DIR/session-<impl>-<n>.json for each session and OUT_DIR/controls-result.json.
Standard library only.
"""
import json, pathlib, sys
sys.dont_write_bytecode = True
from _toollog import invoked, bill
RESULTS = {"controls-v1": [("alpha", 1, False, 4), ("alpha", 2, False, 5), ("beta", 1, False, 4),
                           ("beta", 2, False, 6), ("gamma", 1, False, 5), ("gamma", 2, False, 4)],
           "controls-v2": [("alpha", 1, True, 12), ("alpha", 2, True, 11), ("beta", 1, True, 11),
                           ("beta", 2, False, 4), ("gamma", 1, True, 10), ("gamma", 2, False, 5)]}
def main():
    invoked("run_sessions.py")
    cdir, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=False)
    ctl = json.loads((cdir / "controls.json").read_text())
    print("validating controls ...")
    res = {}
    for name, c in sorted(ctl.items()):
        ok = c["expected"] == c["key"]
        res[name] = ok
        print(f"  control {name}: expected {c['expected']}, answer key says {c['key']} -> "
              f"{'validated' if ok else 'NOT VALIDATED'}")
    (out / "controls-result.json").write_text(json.dumps(res, indent=1) + "\n")
    print("running 6 sessions ...")
    for impl, n, counted, a in RESULTS[cdir.name]:
        bill(f"session {impl}-{n}", 0.03)
        (out / f"session-{impl}-{n}.json").write_text(json.dumps(
            {"implementer": impl, "session": n, "counted": counted, "A": a, "of": 12}) + "\n")
        print(f"  session {impl}-{n}: done")
    print("finished")
if __name__ == "__main__":
    main()
