#!/usr/bin/env python3
"""Call the trial's model endpoint (a stand-in with fixed answers, billed like a real one).

  python3 stub_model.py key CASE      a key for one case: verdict, level, routing, failing IDs
  python3 stub_model.py probe N       one availability probe

Prints the response as JSON. Every call is billed to logs/costs.jsonl. Standard library only.
"""
import json, pathlib, sys
sys.dont_write_bytecode = True
from _toollog import invoked, bill, ROOT
PRICE = {"key": 0.02, "probe": 0.05}
def main():
    invoked("stub_model.py")
    task, arg = sys.argv[1], sys.argv[2]
    head = {"model": "trial-model-1", "host": "api.trial.example", "task": task, "arg": arg}
    if task == "key":
        a = json.loads((ROOT / "answers.json").read_text())[arg]
        reading = dict(a)
        if arg == "case-05":
            reading.pop("routing")
        out = dict(head, reading=reading)
    elif task == "probe":
        out = dict(head, ok=True)
    else:
        sys.exit(f"unknown task {task}")
    bill(f"{task} {arg}", PRICE[task])
    print(json.dumps(out, sort_keys=True))
if __name__ == "__main__":
    main()
