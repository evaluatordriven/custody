"""Shared by the kit's tools: every tool records its own invocation and every billed call. Standard library only."""
import json, pathlib, sys
from datetime import datetime, timezone
ROOT = pathlib.Path(__file__).resolve().parent
def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
def invoked(tool):
    (ROOT / "logs").mkdir(exist_ok=True)
    with open(ROOT / "logs" / "tool-calls.jsonl", "a") as f:
        f.write(json.dumps({"at": now(), "tool": tool, "args": sys.argv[1:]}) + "\n")
def bill(call, usd):
    with open(ROOT / "logs" / "costs.jsonl", "a") as f:
        f.write(json.dumps({"at": now(), "call": call, "usd": usd}) + "\n")
