#!/usr/bin/env python3
"""Score keys against the checker's answers.

  python3 score.py answers.json KEY.json ...

Each KEY.json is one stub_model.py response for one case. Prints {"matches": N, "of": M, "mismatched": [...]}.
Standard library only.
"""
import json, sys
sys.dont_write_bytecode = True
from _toollog import invoked
def main():
    invoked("score.py")
    answers = json.load(open(sys.argv[1]))
    matches, mismatched = 0, []
    for path in sys.argv[2:]:
        k = json.load(open(path))
        a, r = answers[k["arg"]], k["reading"]
        same = all(r[f] == a[f] for f in ("verdict", "level", "routing", "failing"))
        matches += same
        if not same:
            mismatched.append(k["arg"])
    print(json.dumps({"matches": matches, "of": len(sys.argv) - 2, "mismatched": mismatched}))
if __name__ == "__main__":
    main()
