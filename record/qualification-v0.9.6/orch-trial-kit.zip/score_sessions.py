#!/usr/bin/env python3
"""Tabulate a session run.

  python3 score_sessions.py OUT_DIR

Prints one line per session (implementer, session, counted, A of 12) as JSON. Standard library only.
"""
import json, pathlib, sys
sys.dont_write_bytecode = True
from _toollog import invoked
def main():
    invoked("score_sessions.py")
    out = pathlib.Path(sys.argv[1])
    rows = [json.loads(p.read_text()) for p in sorted(out.glob("session-*.json"))]
    print(json.dumps({"run": out.name, "sessions": rows}, indent=1))
if __name__ == "__main__":
    main()
